<?php
session_start();
require_once 'povezava.php';

// Preverjanje prijave in preusmeritev
if (!isset($_SESSION['user_id']) || !isset($_SESSION['vloga'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$vloga = $_SESSION['vloga'];
$ime_priimek = 'Neznan uporabnik';
$urnik = [];

try {
    // Pridobitev imena in priimka
    $sql_ime = "SELECT ime, priimek FROM uporabnik WHERE id_uporabnik = ?";
    $stmt_ime = $pdo->prepare($sql_ime);
    $stmt_ime->execute([$user_id]);
    $uporabnik_data = $stmt_ime->fetch();
    $ime_priimek = $uporabnik_data ? $uporabnik_data['ime'] . ' ' . $uporabnik_data['priimek'] : 'Neznan uporabnik';

    // Pridobitev seznama predmetov (glavni menu na levi)
    $predmeti_menu = [];
    if ($vloga === 'ucenec') {
        $sql_predmeti = "
            SELECT p.id_predmet, p.ime_predmeta, u.id_uporabnik AS id_ucitelja, u.ime AS ime_ucitelja, u.priimek AS priimek_ucitelja
            FROM ucenec_predmet up
            JOIN predmet p ON up.id_predmet = p.id_predmet
            JOIN uporabnik u ON up.id_ucitelj = u.id_uporabnik
            WHERE up.id_ucenec = ?
            ORDER BY p.ime_predmeta
        ";
        $stmt_predmeti = $pdo->prepare($sql_predmeti);
        $stmt_predmeti->execute([$user_id]);
        $predmeti_menu = $stmt_predmeti->fetchAll();
    } elseif ($vloga === 'ucitelj' || $vloga === 'admin') {
         $sql_predmeti = "
            SELECT p.id_predmet, p.ime_predmeta, u.id_uporabnik AS id_ucitelja, u.ime AS ime_ucitelja, u.priimek AS priimek_ucitelja
            FROM ucitelj_predmet up
            JOIN predmet p ON up.id_predmet = p.id_predmet
            JOIN uporabnik u ON up.id_ucitelj = u.id_uporabnik
            WHERE up.id_ucitelj = ?
            ORDER BY p.ime_predmeta
        ";
        $stmt_predmeti = $pdo->prepare($sql_predmeti);
        $stmt_predmeti->execute([$user_id]);
        $predmeti_menu = $stmt_predmeti->fetchAll();
    }

    // Pridobitev urnika (za prikaz po dneh)
    if ($vloga === 'ucenec') {
        $sql_urnik = "
            SELECT ur.dan, ur.ura, p.ime_predmeta, p.id_predmet, u.id_uporabnik AS id_ucitelja, u.ime AS ime_ucitelja, u.priimek AS priimek_ucitelja
            FROM urnik ur
            JOIN predmet p ON ur.id_predmet = p.id_predmet
            JOIN uporabnik u ON ur.id_ucitelj = u.id_uporabnik
            JOIN ucenec_predmet up ON ur.id_predmet = up.id_predmet AND ur.id_ucitelj = up.id_ucitelj
            WHERE up.id_ucenec = ?
            ORDER BY FIELD(dan,'Ponedeljek','Torek','Sreda','Četrtek','Petek'), ura
        ";
        $stmt_urnik = $pdo->prepare($sql_urnik);
        $stmt_urnik->execute([$user_id]);
    } elseif ($vloga === 'ucitelj' || $vloga === 'admin') {
        $sql_urnik = "
            SELECT ur.dan, ur.ura, p.ime_predmeta, p.id_predmet, u.id_uporabnik AS id_ucitelja, u.ime AS ime_ucitelja, u.priimek AS priimek_ucitelja
            FROM urnik ur
            JOIN predmet p ON ur.id_predmet = p.id_predmet
            JOIN uporabnik u ON ur.id_ucitelj = u.id_uporabnik
            WHERE ur.id_ucitelj = ?
            ORDER BY FIELD(dan,'Ponedeljek','Torek','Sreda','Četrtek','Petek'), ura
        ";
        $stmt_urnik = $pdo->prepare($sql_urnik);
        $stmt_urnik->execute([$user_id]);
    }
    
    $urnik_raw = $stmt_urnik->fetchAll();

    // Organizacija urnika po dneh
    foreach ($urnik_raw as $ura) {
        $urnik[$ura['dan']][] = [
            'ura' => $ura['ura'],
            'id_predmet' => $ura['id_predmet'],
            'ime_predmeta' => $ura['ime_predmeta'],
            'id_ucitelja' => $ura['id_ucitelja'],
            'ime_ucitelja' => $ura['ime_ucitelja'] . ' ' . $ura['priimek_ucitelja']
        ];
    }

} catch (\PDOException $e) {
    die("Napaka pri bazi podatkov: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <title>Učilnica - Pregled</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f9f9f9; }
        header { background: #ddd; display: flex; justify-content: space-between; align-items: center; padding: 15px 30px; }
        .main-grid { display: grid; grid-template-columns: 250px 1fr; min-height: 90vh; }
        .sidebar { background: #fff; padding: 15px; border-right: 1px solid #ccc; }
        .content-area { padding: 30px; }
        
        /* Stili za GLAVNI MENU predmetov (predmet-item) - Uporabimo za klik in aktivni status */
        .predmet-item {
            cursor: pointer;
            padding: 10px;
            margin-bottom: 5px;
            border: 1px solid #eee;
            border-radius: 4px;
            background-color: #f7f7f7;
            transition: background-color 0.2s;
        }
        .predmet-item.active, .predmet-item:hover {
            background-color: #cceeff;
        }

        /* Stili za Urnik - Harmonika */
        .day {
            border: 1px solid #ccc;
            margin-bottom: 10px;
            border-radius: 6px;
            overflow: hidden;
            background: #fff;
        }
        .day-header {
            background: #f1f1f1;
            padding: 10px;
            font-weight: bold;
            cursor: pointer;
            user-select: none;
            border-bottom: 1px solid #ccc;
        }
        .day-content {
            display: none; /* Skrije vsebino dni */
            padding: 5px 10px;
            background: #fff;
        }
        /* Elementi znotraj urnika (so že predmet-item) */
        .day-content .predmet-item {
            margin: 5px 0;
            padding: 8px;
            border: none;
            border-bottom: 1px solid #eee;
            background: none;
        }
        .day-content .predmet-item:last-child {
            border-bottom: none;
        }
        .day-content .predmet-item:hover {
             background-color: #e0f7fa;
        }

    </style>
</head>
<body>
<header>
    <div class="logo">**E-Učilnica**</div>
    <div>Prijavljen: **<?php echo htmlspecialchars($ime_priimek); ?>** (<?php echo htmlspecialchars(ucfirst($vloga)); ?>) | <a href="logout.php">Odjava</a></div>
</header>

<div class="main-grid">
    <div class="sidebar">
        <h2>Urnik</h2>
        <?php if (empty($urnik)): ?>
            <p>Urnik ni določen.</p>
        <?php else: ?>
            <?php foreach (array_keys($urnik) as $dan): ?>
                <div class="day">
                    <div class="day-header" data-dan="<?php echo htmlspecialchars($dan); ?>">
                        <?php echo htmlspecialchars($dan); ?> (<?php echo count($urnik[$dan]); ?> ur)
                    </div>
                    <div class="day-content">
                        <?php 
                        $ure_v_dnevu = $urnik[$dan];
                        // Sortiranje po uri (ura je string, zato uporaba <=> za primerjavo)
                        usort($ure_v_dnevu, fn($a, $b) => $a['ura'] <=> $b['ura']);

                        foreach ($ure_v_dnevu as $item): 
                        ?>
                            <div 
                                class="predmet-item" 
                                data-id-predmet="<?php echo htmlspecialchars($item['id_predmet']); ?>"
                                data-id-ucitelja="<?php echo htmlspecialchars($item['id_ucitelja']); ?>"
                                data-ime-predmeta="<?php echo htmlspecialchars($item['ime_predmeta']); ?>"
                                data-ime-ucitelja="<?php echo htmlspecialchars($item['ime_ucitelja']); ?>"
                            >
                                **<?php echo htmlspecialchars($item['ura']); ?>. ura:** <?php echo htmlspecialchars($item['ime_predmeta']); ?><br>
                                <span class="predmet-info">Učitelj: <?php echo htmlspecialchars($item['ime_ucitelja']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <hr>
        
        <h2>Moji Predmeti</h2>
        <?php if (empty($predmeti_menu)): ?>
            <p>Nimate dodeljenih predmetov.</p>
        <?php else: ?>
            <?php foreach ($predmeti_menu as $item): ?>
                <div 
                    class="predmet-item" 
                    data-id-predmet="<?php echo htmlspecialchars($item['id_predmet']); ?>"
                    data-id-ucitelja="<?php echo htmlspecialchars($item['id_ucitelja']); ?>"
                    data-ime-predmeta="<?php echo htmlspecialchars($item['ime_predmeta']); ?>"
                    data-ime-ucitelja="<?php echo htmlspecialchars($item['ime_ucitelja'] . ' ' . $item['priimek_ucitelja']); ?>"
                >
                    <?php echo htmlspecialchars($item['ime_predmeta']); ?><br>
                    <span class="predmet-info">Učitelj: <?php echo htmlspecialchars($item['ime_ucitelja'] . ' ' . $item['priimek_ucitelja']); ?></span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="content-area">
        <h2 id="content-header">Izberite dan in predmet za prikaz detajlov</h2>
        <div id="content-details">
            </div>
    </div>
</div>

<script>
    const vloga = '<?php echo $vloga; ?>';

    // ----------------------------------------------------
    // FUNKCIJE ZA OBLIKOVANJE/INTERAKCIJO
    // ----------------------------------------------------

    /**
     * Nastavi poslušalce za obrazce (Oddaja naloge in Objava nove naloge).
     */
    function setupFormListeners() {
        // Poslušalec za Oddajo/Posodobitev naloge (Učenec)
        const oddajaForm = document.getElementById('oddaja-form');
        if (oddajaForm) {
            oddajaForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const oddajaBtn = this.querySelector('button[type="submit"]');
                oddajaBtn.disabled = true;
                oddajaBtn.textContent = 'Shranjevanje...';

                try {
                    const response = await fetch('ajax_oddaja.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    alert(result.message);
                    oddajaBtn.textContent = result.success ? 'Uspešno oddano!' : 'Poskusi ponovno';
                    oddajaBtn.disabled = false;
                    
                    if (result.success) {
                        // Ponovno naloži vsebino predmeta, da prikaže posodobitev
                        const activeItem = document.querySelector('.predmet-item.active');
                        if (activeItem) activeItem.click();
                    }
                } catch (error) {
                    alert('Napaka pri komunikaciji s strežnikom.');
                    oddajaBtn.disabled = false;
                    oddajaBtn.textContent = 'Oddaj nalogo';
                }
            });
        }
        
        // Poslušalec za Objavljanje nove naloge (Učitelj)
        const nalogaForm = document.getElementById('naloga-form');
        if (nalogaForm) {
            nalogaForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                // formData.append('vloga', vloga);  // Vloga ni potrebna, ker jo PHP dobi iz SESSION
                
                const nalogaBtn = this.querySelector('button[type="submit"]');
                nalogaBtn.disabled = true;
                nalogaBtn.textContent = 'Shranjevanje...';

                try {
                    // KLJUČNA SPREMEMBA: Uporabimo GET parameter za ločevanje kreiranja od prikaza
                    const response = await fetch('ajax_naloga.php?action=create', {
                        method: 'POST',
                        body: formData // FormData se pravilno pošlje z datotekami
                    });
                    
                    // Ker pričakujemo JSON odgovor od ajax_naloga.php
                    const result = await response.json(); 
                    alert(result.message);
                    nalogaBtn.textContent = result.success ? 'Naloga shranjena!' : 'Poskusi ponovno';
                    nalogaBtn.disabled = false;
                    
                    if (result.success) {
                        const activeItem = document.querySelector('.predmet-item.active');
                        if (activeItem) activeItem.click();
                    }
                } catch (error) {
                    // Ta blok se izvede, če je strežnik vrnil ne-JSON odgovor (npr. PHP napaka)
                    console.error('AJAX napaka:', error);
                    alert('Napaka pri komunikaciji s strežnikom. (Preverite konzolo in PHP log za podrobnosti)');
                    nalogaBtn.disabled = false;
                    nalogaBtn.textContent = 'Objavi Nalogo';
                }
            });
        }
    }
    
    /**
     * Nastavi poslušalce za gumbe Pregled/Oceni, Izbriši nalogo in Obrazec za ocenjevanje (Učitelj).
     */
    function setupTeacherListeners() {
        
        // 1. LISTENER ZA GUMBE PREGLED/OCENI (Za vsakega učenca)
        document.querySelectorAll('.pregled-oddaje-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const oddajaId = e.currentTarget.dataset.oddajaId;
                const ucenecIme = e.currentTarget.dataset.ucenecIme;
                
                document.getElementById('content-header').textContent = `Pregled oddaje - ${ucenecIme}`;
                document.getElementById('content-details').innerHTML = '<p>Nalaganje oddaje...</p>';

                try {
                    const response = await fetch('ajax_oddaja_pregled.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            id_oddaja: oddajaId
                        })
                    });
                    const html = await response.text();
                    document.getElementById('content-details').innerHTML = html;
                    
                    setupGradingFormListener(); // Initializacija obrazca za ocenjevanje
                    
                } catch (error) {
                    document.getElementById('content-details').innerHTML = '<p style="color: red;">Napaka pri nalaganju detajlov oddaje.</p>';
                }
            });
        });

        // 2. LISTENER ZA GUMB IZBRIŠI NALOGO
        const deleteBtn = document.getElementById('delete-naloga-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', async (e) => {
                const idNaloga = e.currentTarget.dataset.idNaloga;
                
                if (!confirm("Ali ste prepričani, da želite IZBRISATI to nalogo in VSE oddaje učencev zanjo? Ta akcija je NEPOVRATNA!")) {
                    return;
                }
                
                deleteBtn.disabled = true;
                deleteBtn.textContent = 'Brisanje...';

                try {
                    const response = await fetch('ajax_naloga_delete.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id_naloga: idNaloga })
                    });
                    
                    const result = await response.json();
                    alert(result.message);
                    
                    if (result.success) {
                        const activeItem = document.querySelector('.predmet-item.active');
                        if (activeItem) activeItem.click(); // Ponovno naloži vsebino predmeta
                    } else {
                        deleteBtn.disabled = false;
                        deleteBtn.textContent = 'Izbriši to nalogo';
                    }
                } catch (error) {
                    alert('Napaka pri komunikaciji s strežnikom med brisanjem.');
                    deleteBtn.disabled = false;
                    deleteBtn.textContent = 'Izbriši to nalogo';
                }
            });
        }
    }

    /**
     * Nastavi poslušalca za obrazec za ocenjevanje.
     */
    function setupGradingFormListener() {
        const gradingForm = document.getElementById('grading-form');
        if (gradingForm) { 
            gradingForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                const gradeBtn = this.querySelector('button[type="submit"]');
                gradeBtn.disabled = true;
                gradeBtn.textContent = 'Shranjevanje ocene...';

                try {
                    const response = await fetch('ajax_ocenjevanje.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    alert(result.message);
                    
                    if (result.success) {
                        // Namesto, da klikneš, se vrneš na prejšnjo stran predmeta.
                        const activeItem = document.querySelector('.predmet-item.active');
                        if (activeItem) activeItem.click(); 
                    } else {
                        gradeBtn.textContent = 'Shrani oceno';
                        gradeBtn.disabled = false;
                    }
                } catch (error) {
                    alert('Napaka pri komunikaciji s strežnikom.');
                    gradeBtn.textContent = 'Shrani oceno';
                    gradeBtn.disabled = false;
                }
            });
        }
    }

    /**
     * Omogoči odpiranje in zapiranje dni v urniku (Harmonika - Accordion).
     */
    function setupAccordion() {
        document.querySelectorAll('.day-header').forEach(header => {
            header.addEventListener('click', () => {
                const contentDiv = header.nextElementSibling;
                if (contentDiv && contentDiv.classList.contains('day-content')) {
                    // Preklopi prikaz (display: none/block)
                    contentDiv.style.display = contentDiv.style.display === 'block' ? 'none' : 'block';
                }
            });
        });
    }

    /**
     * Funkcija, ki dejansko sproži AJAX klic za nalaganje vsebine.
     */
    async function loadSubjectContent(item) {
        
        // VZDRŽEVANJE AKTIVNEGA STATUSA
        document.querySelectorAll('.predmet-item').forEach(p => p.classList.remove('active'));
        item.classList.add('active');

        const idPredmet = item.dataset.idPredmet;
        const idUcitelja = item.dataset.idUcitelja;
        const imePredmeta = item.dataset.imePredmeta;
        const imeUcitelja = item.dataset.imeUcitelja;

        // Prikaz nalaganja
        document.getElementById('content-header').textContent = `Nalaganje vsebine za ${imePredmeta} pri ${imeUcitelja}...`;
        document.getElementById('content-details').innerHTML = '<p>Prosimo, počakajte.</p>';

        try {
            // KLJUČNA SPREMEMBA: Klic za prikaz vsebine (naloga, oddaja)
            const response = await fetch('ajax_naloga.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id_predmet: idPredmet,
                    id_ucitelja: idUcitelja, 
                    vloga: vloga
                })
            });
            
            const html = await response.text();
            
            // Vstavitev vsebine
            document.getElementById('content-header').textContent = `Naloge za ${imePredmeta} (Učitelj: ${imeUcitelja})`;
            document.getElementById('content-details').innerHTML = html;
            
            // KLJUČNO: Po nalogi vsebine ponovno inicializiramo poslušalce
            if (vloga === 'ucitelj' || vloga === 'admin') {
                setupTeacherListeners();
            }
            setupFormListeners(); 
            
        } catch (error) {
            document.getElementById('content-header').textContent = `Napaka pri nalaganju za ${imePredmeta}`;
            document.getElementById('content-details').innerHTML = '<p style="color: red;">Prišlo je do napake pri nalaganju podatkov za ta predmet.</p>';
        }
    }


    // ----------------------------------------------------
    // IZVEDBA KODE (DOMContentLoaded)
    // ----------------------------------------------------

    // 1. Nastavi poslušalce za Urnik Harmonika
    setupAccordion(); 

    // 2. Glavna logika: Poslušalec za klike na predmete (iz urnika in menija)
    document.querySelectorAll('.predmet-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            loadSubjectContent(item);
        });
    });

</script>
</body>
</html>