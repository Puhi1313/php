<?php
session_start();
require_once 'povezava.php';
header('Content-Type: application/json'); // Privzeto nastavimo na JSON

// Zaščita pred direktnim dostopom in preverjanje vloge
if (!isset($_SESSION['user_id']) || !isset($_SESSION['vloga'])) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Dostop zavrnjen. Niste prijavljeni."]);
    exit;
}

$user_id = $_SESSION['user_id'];
$vloga = $_SESSION['vloga'];


// --- LOGIKA ZA KREIRANJE NOVE NALOGE (SAMO UČITELJ/ADMIN) ---
// Ta blok se sproži SAMO, če JS pošlje zahtevo s parametrom ?action=create
if ($vloga !== 'ucenec' && (isset($_GET['action']) && $_GET['action'] === 'create')) {
    
    // Uporabimo $_POST in $_FILES za obdelavo FormData (kot jo pošlje JS)
    $id_predmet = $_POST['id_predmet'] ?? null;
    $naslov = trim($_POST['naslov'] ?? '');
    $opis_naloge = trim($_POST['opis_naloge'] ?? '');
    $rok_oddaje = $_POST['rok_oddaje'] ?? null;
    // id_ucitelja izhaja iz SESSION (user_id), če je učitelj, kar je bolj varno.
    $id_ucitelja_za_bazo = $user_id; 

    if (empty($id_predmet) || empty($naslov) || empty($rok_oddaje)) {
        echo json_encode(['success' => false, 'message' => 'Manjkajo nujni podatki (predmet, naslov, rok).']);
        exit;
    }

    $pot_na_strezniku = null;
    
    // Obdelava priložene datoteke (če je prisotna)
    if (isset($_FILES['datoteka']) && $_FILES['datoteka']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/naloge/'; // Pravilna pot do mape
        
        // 1. Ustvarimo mapo, če ne obstaja
        if (!is_dir($upload_dir)) {
            // Poskusimo ustvariti mapo z ustreznimi pravicami
            if (!mkdir($upload_dir, 0777, true)) {
                 echo json_encode(['success' => false, 'message' => 'Napaka: Mapa za nalaganje datotek ni mogla biti ustvarjena.']);
                 exit;
            }
        }
        
        // 2. Pripravimo unikatno ime datoteke
        $file_extension = pathinfo($_FILES['datoteka']['name'], PATHINFO_EXTENSION);
        $file_name_clean = preg_replace('/[^A-Za-z0-9_\-]/', '_', pathinfo($_FILES['datoteka']['name'], PATHINFO_FILENAME));
        // Dodajanje časovnega žiga zagotovi unikatnost
        $new_file_name = $file_name_clean . '_' . time() . '.' . $file_extension; 
        $target_file = $upload_dir . $new_file_name;
        
        // 3. Premik datoteke
        if (move_uploaded_file($_FILES['datoteka']['tmp_name'], $target_file)) {
            $pot_na_strezniku = $target_file;
        } else {
             // To je najpogostejša napaka - težava s pravicami mape ali velikostjo datoteke v php.ini
             error_log("Napaka pri premiku datoteke: " . print_r($_FILES['datoteka']['error'], true));
             echo json_encode(['success' => false, 'message' => 'Napaka pri premiku datoteke na strežnik. Koda napake: ' . $_FILES['datoteka']['error']]);
             exit;
        }
    }
    
    try {
        // Vstavitev nove naloge v bazo
        $sql = "INSERT INTO naloga (id_ucitelj, id_predmet, naslov, opis_naloge, rok_oddaje, pot_na_strezniku) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id_ucitelja_za_bazo, $id_predmet, $naslov, $opis_naloge, $rok_oddaje, $pot_na_strezniku]);

        echo json_encode(['success' => true, 'message' => 'Naloga uspešno objavljena!']);

    } catch (\PDOException $e) {
        // Če je prišlo do SQL napake, jo vrni nazaj v JS
        error_log("Napaka pri objavi naloge: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Napaka baze: ' . $e->getMessage()]);
    }

    exit;
}


// --- LOGIKA ZA PRIKAZ NALOGE (UČENEC IN UČITELJ) ---
header('Content-Type: text/html'); // Preklopimo na HTML, ker vključujemo .php datoteko

// Podatki, poslani preko AJAX iz ucilnicaPage.php
$data = json_decode(file_get_contents("php://input"), true);
$id_predmet = $data['id_predmet'] ?? null;
$id_ucitelja = $data['id_ucitelja'] ?? null; // ID učitelja, ki poučuje ta predmet (za filtriranje naloge)

if (empty($id_predmet) || empty($id_ucitelja)) {
    echo "Izberite predmet.";
    exit;
}

// Pridobi zadnjo nalogo za ta predmet in učitelja
try {
    // Opomba: Naloga je filtrirana po id_predmet IN id_ucitelj. Če je več nalog, se vzame zadnja.
    $sql_naloga = "SELECT * FROM naloga WHERE id_predmet = ? AND id_ucitelj = ? ORDER BY id_naloga DESC LIMIT 1";
    $stmt_naloga = $pdo->prepare($sql_naloga);
    $stmt_naloga->execute([$id_predmet, $id_ucitelja]);
    $naloga = $stmt_naloga->fetch();
} catch (\PDOException $e) {
    echo "<p style='color: red;'>Napaka pri bazi podatkov med iskanjem naloge: " . $e->getMessage() . "</p>";
    exit;
}


// Vključi ustrezno datoteko glede na vlogo
if ($vloga === 'ucenec') {
    // Tukaj imamo dostop do $naloga, $pdo, $user_id
    include 'naloga_ucenec.php';
} elseif ($vloga === 'ucitelj' || $vloga === 'admin') {
    // Tukaj imamo dostop do $naloga, $pdo, $id_predmet, $id_ucitelja, $user_id
    include 'naloga_ucitelj.php';
} else {
    echo "Neveljavna vloga.";
}
// Skripta se konča, vsebina (HTML) iz vključene datoteke je poslana nazaj v JS